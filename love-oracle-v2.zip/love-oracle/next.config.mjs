/** @type {import('next').NextConfig} */
const nextConfig = {
  // Cho phép @huggingface/transformers và onnxruntime chạy trong server
  serverExternalPackages: ['@huggingface/transformers', 'onnxruntime-node'],

  // Turbopack config (Next.js 16 default bundler)
  turbopack: {
    // Không cần custom rule — serverExternalPackages đã xử lý onnxruntime
  },
};

export default nextConfig;
