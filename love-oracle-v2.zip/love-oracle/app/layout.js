import './globals.css';

export const metadata = {
  title: 'Love Oracle — Cosmic Compatibility',
  description: 'Discover the mystical compatibility between two souls. An AI-powered love oracle for entertainment.',
  keywords: 'love compatibility, oracle, astrology, entertainment, relationship',
};

export const viewport = {
  width: 'device-width',
  initialScale: 1,
  themeColor: '#0a0314',
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
