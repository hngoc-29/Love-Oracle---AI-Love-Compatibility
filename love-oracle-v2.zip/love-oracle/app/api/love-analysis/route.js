import { NextResponse } from 'next/server';
import { analyzeCompatibility } from '@/lib/love-engine';
import { generateProphecy } from '@/lib/ai-writer';

export async function POST(request) {
  try {
    const body = await request.json();
    const { personA, personB } = body;

    // Validate input
    if (!personA?.name || !personA?.age || !personB?.name || !personB?.age) {
      return NextResponse.json(
        { error: 'Both people must have a name and age.' },
        { status: 400 }
      );
    }

    if (
      typeof personA.age !== 'number' || personA.age < 1 || personA.age > 120 ||
      typeof personB.age !== 'number' || personB.age < 1 || personB.age > 120
    ) {
      return NextResponse.json(
        { error: 'Age must be a number between 1 and 120.' },
        { status: 400 }
      );
    }

    if (personA.name.trim().length < 1 || personB.name.trim().length < 1) {
      return NextResponse.json(
        { error: 'Names must not be empty.' },
        { status: 400 }
      );
    }

    // Step 1: Deterministic love analysis (no AI)
    const analysis = analyzeCompatibility(personA, personB);

    // Step 2: AI-written prophecy based on analysis
    const prophecy = await generateProphecy(personA, personB, analysis);

    return NextResponse.json({
      personA,
      personB,
      analysis,
      prophecy,
    });
  } catch (error) {
    console.error('Love analysis error:', error);
    return NextResponse.json(
      { error: 'The Oracle encountered an unexpected disturbance. Please try again.' },
      { status: 500 }
    );
  }
}
