'use client';

import { motion } from 'framer-motion';
import ScoreCircle from './ScoreCircle';

function Tag({ children, color = 'violet' }) {
  const colors = {
    violet: 'bg-violet-900/50 text-violet-200 border-violet-500/30',
    pink: 'bg-pink-900/40 text-pink-200 border-pink-500/30',
    rose: 'bg-rose-900/40 text-rose-200 border-rose-500/30',
  };
  return (
    <span className={`inline-block text-xs px-2.5 py-1 rounded-full border ${colors[color]} font-medium`}>
      {children}
    </span>
  );
}

function Section({ title, emoji, children, delay = 0 }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay, duration: 0.5 }}
      className="rounded-2xl border border-violet-500/20 bg-violet-950/40 backdrop-blur-sm p-5"
    >
      <h3 className="flex items-center gap-2 text-violet-300 font-semibold text-sm mb-3 uppercase tracking-wider">
        <span>{emoji}</span> {title}
      </h3>
      {children}
    </motion.div>
  );
}

export default function ResultCard({ data, onReset }) {
  const { personA, personB, analysis, prophecy } = data;

  function handleShare() {
    const text = `✨ Love Oracle says ${personA.name} & ${personB.name} have ${analysis.score}% compatibility — ${analysis.level.label} ${analysis.level.emoji}\n\nConsult the Oracle: ${window.location.origin}`;
    if (navigator.share) {
      navigator.share({ title: 'Love Oracle', text }).catch(() => {});
    } else {
      navigator.clipboard.writeText(text);
      alert('Result copied to clipboard! ✨');
    }
  }

  const paragraphs = prophecy.split(/\n\n+/).filter(Boolean);

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.6 }}
      className="w-full max-w-2xl mx-auto space-y-4"
    >
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center py-4"
      >
        <p className="text-violet-400 text-sm uppercase tracking-widest mb-1">The Oracle has spoken</p>
        <h2 className="text-2xl font-bold text-white">
          {personA.name} <span className="text-pink-400">&</span> {personB.name}
        </h2>
      </motion.div>

      {/* Score + quick stats */}
      <Section title="Compatibility" emoji="💫" delay={0.1}>
        <div className="flex flex-col sm:flex-row items-center gap-6">
          <ScoreCircle score={analysis.score} level={analysis.level} />

          <div className="flex-1 grid grid-cols-2 gap-3 w-full">
            {/* Love color */}
            <div className="flex flex-col gap-1.5 p-3 rounded-xl bg-violet-900/30">
              <span className="text-violet-400 text-xs uppercase tracking-wide">Love Color</span>
              <div className="flex items-center gap-2">
                <div
                  className="w-5 h-5 rounded-full border border-white/20 flex-shrink-0"
                  style={{ background: analysis.loveColor.hex }}
                />
                <span className="text-violet-100 text-sm font-medium">{analysis.loveColor.name}</span>
              </div>
              <span className="text-violet-400 text-xs">{analysis.loveColor.meaning}</span>
            </div>

            {/* Lucky number */}
            <div className="flex flex-col gap-1.5 p-3 rounded-xl bg-violet-900/30">
              <span className="text-violet-400 text-xs uppercase tracking-wide">Lucky Number</span>
              <span className="text-3xl font-bold text-pink-300">{analysis.luckyNumber}</span>
            </div>

            {/* Element */}
            <div className="flex flex-col gap-1.5 p-3 rounded-xl bg-violet-900/30">
              <span className="text-violet-400 text-xs uppercase tracking-wide">Element</span>
              <span className="text-lg">{analysis.element.emoji} {analysis.element.label}</span>
              <span className="text-violet-400 text-xs">{analysis.element.desc}</span>
            </div>

            {/* Destiny symbol */}
            <div className="flex flex-col gap-1.5 p-3 rounded-xl bg-violet-900/30">
              <span className="text-violet-400 text-xs uppercase tracking-wide">Destiny Symbol</span>
              <span className="text-2xl">{analysis.destinySymbol.symbol}</span>
              <span className="text-violet-200 text-xs">{analysis.destinySymbol.name}</span>
            </div>
          </div>
        </div>
      </Section>

      {/* Personalities */}
      <Section title="Personality Energies" emoji="✨" delay={0.2}>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <p className="text-pink-300 font-medium text-sm mb-2">{personA.name}</p>
            <div className="flex flex-wrap gap-1.5">
              {analysis.traits.personA.map(t => <Tag key={t} color="pink">{t}</Tag>)}
            </div>
          </div>
          <div>
            <p className="text-violet-300 font-medium text-sm mb-2">{personB.name}</p>
            <div className="flex flex-wrap gap-1.5">
              {analysis.traits.personB.map(t => <Tag key={t} color="violet">{t}</Tag>)}
            </div>
          </div>
        </div>
      </Section>

      {/* Insights */}
      <Section title="Relationship Insights" emoji="🔮" delay={0.3}>
        <div className="space-y-3 text-sm">
          {[
            { label: '💪 Strength', text: analysis.strength },
            { label: '🌊 Communication', text: analysis.communicationStyle },
            { label: '💞 Emotional Bond', text: analysis.emotionalConnection },
            { label: '🌱 Challenge', text: analysis.conflict },
            { label: '🌟 Future Potential', text: analysis.futurePotential },
          ].map(({ label, text }) => (
            <div key={label} className="flex gap-3">
              <span className="text-violet-400 text-xs font-semibold whitespace-nowrap pt-0.5 w-28 shrink-0">{label}</span>
              <span className="text-violet-200 text-xs leading-relaxed">{text}</span>
            </div>
          ))}
        </div>
      </Section>

      {/* Date ideas */}
      <Section title="Adventures to Share" emoji="🌹" delay={0.35}>
        <ul className="space-y-2">
          {analysis.dateIdeas.map((idea, i) => (
            <li key={i} className="flex items-start gap-2 text-sm text-violet-200">
              <span className="text-pink-400 mt-0.5">✦</span>
              <span>{idea}</span>
            </li>
          ))}
        </ul>
      </Section>

      {/* AI Prophecy */}
      <Section title="The Oracle's Prophecy" emoji="🌙" delay={0.4}>
        <div className="space-y-3">
          {paragraphs.map((para, i) => (
            <motion.p
              key={i}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.5 + i * 0.12 }}
              className="text-violet-100 text-sm leading-relaxed"
            >
              {para}
            </motion.p>
          ))}
        </div>

        <div className="mt-4 pt-4 border-t border-violet-700/30 flex items-center gap-2">
          <span className="text-violet-500 text-xs italic">
            🔮 For entertainment purposes only — your destiny is yours to write
          </span>
        </div>
      </Section>

      {/* Action buttons */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.7 }}
        className="flex gap-3 pb-8"
      >
        <button
          onClick={handleShare}
          className="flex-1 py-3 rounded-xl text-sm font-medium border border-violet-500/40 text-violet-300 hover:bg-violet-900/40 transition-colors flex items-center justify-center gap-2"
        >
          🔗 Share Result
        </button>
        <button
          onClick={onReset}
          className="flex-1 py-3 rounded-xl text-sm font-medium text-white transition-all flex items-center justify-center gap-2"
          style={{ background: 'linear-gradient(135deg, #7c3aed, #a855f7)' }}
        >
          🔮 New Reading
        </button>
      </motion.div>
    </motion.div>
  );
}
