'use client';

import { useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import CrystalBall from './CrystalBall';
import LoveForm from './LoveForm';
import LoadingAnimation from './LoadingAnimation';
import ResultCard from './ResultCard';
import StarryBackground from './StarryBackground';

const PHASES = {
  HOME: 'home',
  FORM: 'form',
  LOADING: 'loading',
  RESULT: 'result',
};

export default function OracleApp() {
  const [phase, setPhase] = useState(PHASES.HOME);
  const [result, setResult] = useState(null);
  const [error, setError] = useState('');

  async function handleAnalyze({ personA, personB }) {
    setError('');
    setPhase(PHASES.LOADING);

    // Minimum loading time for magical effect
    const minDelay = new Promise(res => setTimeout(res, 3500));

    try {
      const [response] = await Promise.all([
        fetch('/api/love-analysis', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ personA, personB }),
        }),
        minDelay,
      ]);

      if (!response.ok) {
        const err = await response.json();
        throw new Error(err.error || 'The Oracle was silent. Please try again.');
      }

      const data = await response.json();
      setResult(data);
      setPhase(PHASES.RESULT);
    } catch (e) {
      setError(e.message);
      setPhase(PHASES.FORM);
    }
  }

  function handleReset() {
    setResult(null);
    setError('');
    setPhase(PHASES.FORM);
  }

  return (
    <>
      <StarryBackground />

      <main className="relative z-10 min-h-screen flex flex-col items-center justify-start px-4 py-8">
        <AnimatePresence mode="wait">

          {/* HOME */}
          {phase === PHASES.HOME && (
            <motion.div
              key="home"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              transition={{ duration: 0.5 }}
              className="flex flex-col items-center justify-center min-h-screen gap-8 text-center"
            >
              <motion.div
                animate={{ y: [0, -12, 0] }}
                transition={{ duration: 4, repeat: Infinity, ease: 'easeInOut' }}
              >
                <CrystalBall size={220} glowing pulsing />
              </motion.div>

              <div className="space-y-3">
                <motion.h1
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.3 }}
                  className="text-5xl sm:text-6xl font-bold tracking-tight"
                  style={{
                    background: 'linear-gradient(135deg, #e9d5ff, #f9a8d4, #c4b5fd)',
                    WebkitBackgroundClip: 'text',
                    WebkitTextFillColor: 'transparent',
                  }}
                >
                  Love Oracle
                </motion.h1>

                <motion.p
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.5 }}
                  className="text-violet-300 text-lg max-w-sm mx-auto"
                >
                  Unlock the cosmic secrets between two souls
                </motion.p>
              </div>

              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.7 }}
                className="flex flex-col items-center gap-4"
              >
                <motion.button
                  onClick={() => setPhase(PHASES.FORM)}
                  whileHover={{ scale: 1.05, boxShadow: '0 0 40px rgba(167,139,250,0.5)' }}
                  whileTap={{ scale: 0.97 }}
                  className="px-10 py-4 rounded-2xl text-white font-semibold text-lg tracking-wide"
                  style={{
                    background: 'linear-gradient(135deg, #7c3aed, #a855f7, #ec4899)',
                    boxShadow: '0 0 25px rgba(167,139,250,0.3)',
                  }}
                >
                  ✨ Begin Your Reading
                </motion.button>

                <p className="text-violet-500 text-xs">
                  For entertainment only · All readings are mystical and non-binding
                </p>
              </motion.div>

              {/* Floating runes */}
              {['💫', '🌙', '⭐', '🔮', '✨'].map((rune, i) => (
                <motion.span
                  key={i}
                  className="fixed text-xl pointer-events-none select-none"
                  style={{
                    left: `${10 + i * 20}%`,
                    top: `${20 + (i % 3) * 25}%`,
                    opacity: 0.2,
                  }}
                  animate={{
                    y: [0, -20, 0],
                    opacity: [0.15, 0.35, 0.15],
                    rotate: [0, 15, 0],
                  }}
                  transition={{
                    duration: 3 + i * 0.7,
                    repeat: Infinity,
                    delay: i * 0.5,
                    ease: 'easeInOut',
                  }}
                >
                  {rune}
                </motion.span>
              ))}
            </motion.div>
          )}

          {/* FORM */}
          {phase === PHASES.FORM && (
            <motion.div
              key="form"
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.4 }}
              className="w-full max-w-lg mx-auto pt-12 pb-8"
            >
              {/* Back to home */}
              <button
                onClick={() => setPhase(PHASES.HOME)}
                className="flex items-center gap-1.5 text-violet-400 hover:text-violet-200 text-sm mb-6 transition-colors"
              >
                ← Back
              </button>

              <div className="flex justify-center mb-6">
                <CrystalBall size={100} glowing />
              </div>

              {error && (
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="mb-4 p-3 rounded-xl bg-red-900/30 border border-red-500/30 text-red-300 text-sm text-center"
                >
                  {error}
                </motion.div>
              )}

              <LoveForm onSubmit={handleAnalyze} loading={false} />
            </motion.div>
          )}

          {/* LOADING */}
          {phase === PHASES.LOADING && (
            <motion.div
              key="loading"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="flex items-center justify-center min-h-screen w-full"
            >
              <LoadingAnimation />
            </motion.div>
          )}

          {/* RESULT */}
          {phase === PHASES.RESULT && result && (
            <motion.div
              key="result"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="w-full max-w-2xl mx-auto pt-8"
            >
              <ResultCard data={result} onReset={handleReset} />
            </motion.div>
          )}

        </AnimatePresence>
      </main>
    </>
  );
}
