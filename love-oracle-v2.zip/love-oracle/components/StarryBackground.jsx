'use client';

import { useEffect, useRef } from 'react';

const STAR_COUNT = 160;

function randomBetween(a, b) {
  return a + Math.random() * (b - a);
}

export default function StarryBackground() {
  const canvasRef = useRef(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');

    let animId;
    let stars = [];
    let particles = [];

    function resize() {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    }

    function initStars() {
      stars = Array.from({ length: STAR_COUNT }, () => ({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        r: randomBetween(0.3, 2.2),
        opacity: randomBetween(0.3, 1),
        twinkleSpeed: randomBetween(0.005, 0.025),
        twinkleDir: Math.random() > 0.5 ? 1 : -1,
      }));

      particles = Array.from({ length: 25 }, () => ({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        r: randomBetween(1, 3),
        vx: randomBetween(-0.15, 0.15),
        vy: randomBetween(-0.25, -0.05),
        opacity: randomBetween(0.2, 0.6),
        color: Math.random() > 0.5 ? '#c4b5fd' : '#f9a8d4',
      }));
    }

    function draw(t) {
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      // Background gradient
      const bg = ctx.createLinearGradient(0, 0, 0, canvas.height);
      bg.addColorStop(0, '#0a0314');
      bg.addColorStop(0.4, '#0f0a2e');
      bg.addColorStop(1, '#1a0533');
      ctx.fillStyle = bg;
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      // Moon
      const moonX = canvas.width * 0.82;
      const moonY = canvas.height * 0.12;
      const moonGlow = ctx.createRadialGradient(moonX, moonY, 0, moonX, moonY, 90);
      moonGlow.addColorStop(0, 'rgba(253,230,138,0.12)');
      moonGlow.addColorStop(1, 'transparent');
      ctx.fillStyle = moonGlow;
      ctx.beginPath();
      ctx.arc(moonX, moonY, 90, 0, Math.PI * 2);
      ctx.fill();

      ctx.beginPath();
      ctx.arc(moonX, moonY, 32, 0, Math.PI * 2);
      ctx.fillStyle = '#fef9c3';
      ctx.fill();

      ctx.beginPath();
      ctx.arc(moonX + 12, moonY - 4, 26, 0, Math.PI * 2);
      ctx.fillStyle = '#0f0a2e';
      ctx.fill();

      // Stars
      stars.forEach(star => {
        star.opacity += star.twinkleSpeed * star.twinkleDir;
        if (star.opacity >= 1) { star.twinkleDir = -1; star.opacity = 1; }
        if (star.opacity <= 0.2) { star.twinkleDir = 1; star.opacity = 0.2; }

        ctx.beginPath();
        ctx.arc(star.x, star.y, star.r, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(255,255,255,${star.opacity})`;
        ctx.fill();
      });

      // Floating particles
      particles.forEach(p => {
        p.x += p.vx;
        p.y += p.vy;
        p.opacity += Math.sin(t * 0.001 + p.x) * 0.003;
        p.opacity = Math.max(0.1, Math.min(0.7, p.opacity));

        if (p.y < -5) { p.y = canvas.height + 5; p.x = Math.random() * canvas.width; }
        if (p.x < -5) p.x = canvas.width + 5;
        if (p.x > canvas.width + 5) p.x = -5;

        ctx.beginPath();
        ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
        ctx.fillStyle = p.color.replace(')', `,${p.opacity})`).replace('rgb', 'rgba').replace('#c4b5fd', `rgba(196,181,253,${p.opacity})`).replace('#f9a8d4', `rgba(249,168,212,${p.opacity})`);

        // Fix: just use direct rgba
        ctx.fillStyle = p.color === '#c4b5fd'
          ? `rgba(196,181,253,${p.opacity})`
          : `rgba(249,168,212,${p.opacity})`;
        ctx.fill();
      });

      animId = requestAnimationFrame(draw);
    }

    resize();
    initStars();
    animId = requestAnimationFrame(draw);

    window.addEventListener('resize', () => { resize(); initStars(); });
    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener('resize', resize);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      className="fixed inset-0 w-full h-full pointer-events-none"
      style={{ zIndex: 0 }}
    />
  );
}
