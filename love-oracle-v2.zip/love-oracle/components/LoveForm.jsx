'use client';

import { motion } from 'framer-motion';
import { useState } from 'react';

function PersonField({ label, emoji, value, onChange, nameValue, onNameChange, disabled }) {
  return (
    <motion.div
      className="flex flex-col gap-3 p-5 rounded-2xl border border-violet-500/30 bg-violet-950/40 backdrop-blur-sm"
      whileHover={{ borderColor: 'rgba(167,139,250,0.5)' }}
      transition={{ duration: 0.2 }}
    >
      <div className="flex items-center gap-2 mb-1">
        <span className="text-2xl">{emoji}</span>
        <span className="text-violet-300 font-semibold tracking-wide text-sm uppercase">
          {label}
        </span>
      </div>

      <div className="space-y-3">
        <div>
          <label className="text-violet-400 text-xs mb-1.5 block">Name</label>
          <input
            type="text"
            value={nameValue}
            onChange={e => onNameChange(e.target.value)}
            placeholder="Enter name..."
            disabled={disabled}
            className="w-full bg-violet-900/40 border border-violet-500/30 rounded-xl px-4 py-2.5 text-violet-100 placeholder-violet-500 focus:outline-none focus:border-violet-400 transition-colors text-sm disabled:opacity-50"
            maxLength={50}
          />
        </div>

        <div>
          <label className="text-violet-400 text-xs mb-1.5 block">Age</label>
          <input
            type="number"
            value={value}
            onChange={e => onChange(e.target.value)}
            placeholder="Age..."
            disabled={disabled}
            min={1}
            max={120}
            className="w-full bg-violet-900/40 border border-violet-500/30 rounded-xl px-4 py-2.5 text-violet-100 placeholder-violet-500 focus:outline-none focus:border-violet-400 transition-colors text-sm disabled:opacity-50"
          />
        </div>
      </div>
    </motion.div>
  );
}

export default function LoveForm({ onSubmit, loading }) {
  const [nameA, setNameA] = useState('');
  const [ageA, setAgeA] = useState('');
  const [nameB, setNameB] = useState('');
  const [ageB, setAgeB] = useState('');
  const [error, setError] = useState('');

  function handleSubmit(e) {
    e.preventDefault();
    setError('');

    if (!nameA.trim() || !nameB.trim()) {
      setError('Please enter names for both people.');
      return;
    }

    const parsedAgeA = parseInt(ageA, 10);
    const parsedAgeB = parseInt(ageB, 10);

    if (isNaN(parsedAgeA) || parsedAgeA < 1 || parsedAgeA > 120) {
      setError('Please enter a valid age for the first person (1-120).');
      return;
    }
    if (isNaN(parsedAgeB) || parsedAgeB < 1 || parsedAgeB > 120) {
      setError('Please enter a valid age for the second person (1-120).');
      return;
    }

    onSubmit({
      personA: { name: nameA.trim(), age: parsedAgeA },
      personB: { name: nameB.trim(), age: parsedAgeB },
    });
  }

  const isReady = nameA.trim() && nameB.trim() && ageA && ageB;

  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6, delay: 0.2 }}
      className="w-full max-w-lg mx-auto"
    >
      <div className="text-center mb-6">
        <h2 className="text-violet-200 text-xl font-semibold mb-1">Two Souls, One Question</h2>
        <p className="text-violet-400 text-sm">Enter the names and ages, and let the Oracle speak.</p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        <PersonField
          label="First Person"
          emoji="💜"
          nameValue={nameA}
          onNameChange={setNameA}
          value={ageA}
          onChange={setAgeA}
          disabled={loading}
        />

        <div className="flex items-center gap-3">
          <div className="flex-1 h-px bg-violet-700/40" />
          <span className="text-violet-400 text-lg">💫</span>
          <div className="flex-1 h-px bg-violet-700/40" />
        </div>

        <PersonField
          label="Second Person"
          emoji="🌹"
          nameValue={nameB}
          onNameChange={setNameB}
          value={ageB}
          onChange={setAgeB}
          disabled={loading}
        />

        {error && (
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-pink-400 text-sm text-center bg-pink-950/30 rounded-xl py-2 px-4 border border-pink-500/20"
          >
            {error}
          </motion.p>
        )}

        <motion.button
          type="submit"
          disabled={loading || !isReady}
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          className="w-full py-4 rounded-2xl font-semibold text-white tracking-wide text-base disabled:opacity-40 disabled:cursor-not-allowed transition-all"
          style={{
            background: isReady && !loading
              ? 'linear-gradient(135deg, #7c3aed, #a855f7, #ec4899)'
              : 'rgba(109,40,217,0.3)',
            boxShadow: isReady && !loading ? '0 0 30px rgba(167,139,250,0.3)' : 'none',
          }}
        >
          {loading ? (
            <span className="flex items-center justify-center gap-2">
              <motion.span
                animate={{ rotate: 360 }}
                transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}
                className="inline-block"
              >
                🔮
              </motion.span>
              Reading the stars...
            </span>
          ) : (
            '✨ Consult the Oracle'
          )}
        </motion.button>
      </form>

      <p className="text-violet-500 text-xs text-center mt-4">
        For entertainment purposes only · The Oracle sees, but destiny is yours to write
      </p>
    </motion.div>
  );
}
